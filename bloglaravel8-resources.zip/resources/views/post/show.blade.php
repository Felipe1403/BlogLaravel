<h1>Post: {{$post->title}}</h1>

<p>by: {{$post->author->name}}</p>

<p>{{$post->content}}</p>

@foreach ($post->comments as $comment)
    <p><b>{{$comment->author->name}}: </b>  {{ $comment->comment}}</p>
@endforeach