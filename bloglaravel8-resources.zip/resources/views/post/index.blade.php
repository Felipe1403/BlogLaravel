
<h1>Posts</h1>

@foreach ($posts as $post)
    <p><a href="{{route('post.show',$post->id)}}">{{ $post->title }}</a></p>
@endforeach