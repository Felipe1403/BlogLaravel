
<h1>Categories</h1>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><a href="<?php echo e(route('category.show',$category->id)); ?>"><?php echo e($category->title); ?></a></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\bloglaravel8\resources\views/category/index.blade.php ENDPATH**/ ?>