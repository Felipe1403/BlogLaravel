<h1>Post: <?php echo e($post->title); ?></h1>
<p>by: <?php echo e($post->author->name); ?></p>
<p><?php echo e($post->content); ?></p>
<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><b><?php echo e($comment->author->name); ?>: </b>  <?php echo e($comment->comment); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\bloglaravel8\resources\views/post/show.blade.php ENDPATH**/ ?>