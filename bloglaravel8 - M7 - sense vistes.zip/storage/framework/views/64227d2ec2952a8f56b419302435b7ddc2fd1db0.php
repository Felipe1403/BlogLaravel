
<h1>Posts</h1>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><a href="<?php echo e(route('post.show',$post->id)); ?>"><?php echo e($post->title); ?></a></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\bloglaravel8\resources\views/post/index.blade.php ENDPATH**/ ?>