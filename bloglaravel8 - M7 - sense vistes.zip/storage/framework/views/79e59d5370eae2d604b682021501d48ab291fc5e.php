
<h1>Category <?php echo e($category->title); ?></h1>

<?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><a href="<?php echo e(route('post.show',$post->id)); ?>"><?php echo e($post->title); ?></a></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\bloglaravel8\resources\views/category/show.blade.php ENDPATH**/ ?>